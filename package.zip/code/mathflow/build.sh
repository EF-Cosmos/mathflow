#!/bin/bash
cd /workspace/code/mathflow
pnpm install --prefer-offline
pnpm run build
