#!/bin/bash
set -e

echo "开始初始化 MathFlow 数据库..."

# 创建扩展
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
    -- 启用必要的扩展
    CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
    CREATE EXTENSION IF NOT EXISTS "pgcrypto";
    CREATE EXTENSION IF NOT EXISTS "pg_trgm";
    CREATE EXTENSION IF NOT EXISTS "btree_gin";
    CREATE EXTENSION IF NOT EXISTS "btree_gist";

    -- 创建自定义类型
    CREATE TYPE user_role AS ENUM ('admin', 'teacher', 'student', 'viewer');
    CREATE TYPE derivation_status AS ENUM ('draft', 'published', 'archived');
    CREATE TYPE difficulty_level AS ENUM ('basic', 'intermediate', 'advanced', 'expert');
    CREATE TYPE operation_type AS ENUM ('addition', 'subtraction', 'multiplication', 'division', 'complex');

    -- 创建时间戳函数
    CREATE OR REPLACE FUNCTION update_updated_at_column()
    RETURNS TRIGGER AS \$\$
    BEGIN
        NEW.updated_at = CURRENT_TIMESTAMP;
        RETURN NEW;
    END;
    \$ language 'plpgsql';

    -- 创建用户配置表
    CREATE TABLE IF NOT EXISTS profiles (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        user_id UUID NOT NULL,
        username VARCHAR(50) UNIQUE NOT NULL,
        full_name VARCHAR(100),
        avatar_url TEXT,
        role user_role DEFAULT 'student',
        preferences JSONB DEFAULT '{}',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );

    -- 创建数学模板表
    CREATE TABLE IF NOT EXISTS math_templates (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        title VARCHAR(200) NOT NULL,
        description TEXT,
        content JSONB NOT NULL,
        difficulty difficulty_level DEFAULT 'basic',
        category VARCHAR(100),
        tags TEXT[],
        author_id UUID REFERENCES profiles(id),
        is_public BOOLEAN DEFAULT false,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );

    -- 创建推导步骤表
    CREATE TABLE IF NOT EXISTS derivation_steps (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        step_number INTEGER NOT NULL,
        content JSONB NOT NULL,
        explanation TEXT,
        mathematical_notation TEXT,
        operation operation_type,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );

    -- 创建推导表
    CREATE TABLE IF NOT EXISTS derivations (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        title VARCHAR(200) NOT NULL,
        description TEXT,
        template_id UUID REFERENCES math_templates(id),
        status derivation_status DEFAULT 'draft',
        final_result JSONB,
        metadata JSONB DEFAULT '{}',
        author_id UUID REFERENCES profiles(id),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );

    -- 创建推导步骤关联表
    CREATE TABLE IF NOT EXISTS derivation_step_relations (
        derivation_id UUID REFERENCES derivations(id) ON DELETE CASCADE,
        step_id UUID REFERENCES derivation_steps(id) ON DELETE CASCADE,
        step_order INTEGER NOT NULL,
        PRIMARY KEY (derivation_id, step_id)
    );

    -- 创建AI对话表
    CREATE TABLE IF NOT EXISTS ai_conversations (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        user_id UUID REFERENCES profiles(id),
        title VARCHAR(200),
        context JSONB DEFAULT '{}',
        model VARCHAR(50) DEFAULT 'gpt-3.5-turbo',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );

    -- 创建AI消息表
    CREATE TABLE IF NOT EXISTS ai_messages (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        conversation_id UUID REFERENCES ai_conversations(id) ON DELETE CASCADE,
        role VARCHAR(20) NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
        content TEXT NOT NULL,
        metadata JSONB DEFAULT '{}',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );

    -- 创建索引以提高查询性能
    CREATE INDEX IF NOT EXISTS idx_profiles_user_id ON profiles(user_id);
    CREATE INDEX IF NOT EXISTS idx_profiles_username ON profiles(username);
    CREATE INDEX IF NOT EXISTS idx_math_templates_author ON math_templates(author_id);
    CREATE INDEX IF NOT EXISTS idx_math_templates_category ON math_templates(category);
    CREATE INDEX IF NOT EXISTS idx_math_templates_tags ON math_templates USING GIN(tags);
    CREATE INDEX IF NOT EXISTS idx_derivations_author ON derivations(author_id);
    CREATE INDEX IF NOT EXISTS idx_derivations_template ON derivations(template_id);
    CREATE INDEX IF NOT EXISTS idx_derivations_status ON derivations(status);
    CREATE INDEX IF NOT EXISTS idx_derivation_steps_operation ON derivation_steps(operation);
    CREATE INDEX IF NOT EXISTS idx_ai_conversations_user ON ai_conversations(user_id);
    CREATE INDEX IF NOT EXISTS idx_ai_messages_conversation ON ai_messages(conversation_id);

    -- 创建更新时间戳触发器
    CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
        FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    CREATE TRIGGER update_math_templates_updated_at BEFORE UPDATE ON math_templates
        FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    CREATE TRIGGER update_derivations_updated_at BEFORE UPDATE ON derivations
        FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    CREATE TRIGGER update_ai_conversations_updated_at BEFORE UPDATE ON ai_conversations
        FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

    -- 插入示例数据
    INSERT INTO profiles (user_id, username, full_name, role) VALUES 
        (uuid_generate_v4(), 'admin', '系统管理员', 'admin'),
        (uuid_generate_v4(), 'teacher1', '数学教师', 'teacher'),
        (uuid_generate_v4(), 'student1', '学生用户', 'student')
    ON CONFLICT (username) DO NOTHING;

    -- 插入示例数学模板
    INSERT INTO math_templates (title, description, content, difficulty, category, tags, author_id) 
    SELECT 
        '二次方程求解',
        '标准二次方程 ax² + bx + c = 0 的求解模板',
        '{"type": "quadratic", "formula": "ax² + bx + c = 0"}',
        'intermediate',
        '代数',
        ARRAY['二次方程', '代数', '求解'],
        p.id
    FROM profiles p WHERE p.username = 'teacher1'
    ON CONFLICT DO NOTHING;

    -- 创建视图以简化常用查询
    CREATE OR REPLACE VIEW derivation_with_steps AS
    SELECT 
        d.id,
        d.title,
        d.description,
        d.status,
        d.final_result,
        d.metadata,
        p.username as author,
        ds.steps
    FROM derivations d
    JOIN profiles p ON d.author_id = p.id
    LEFT JOIN (
        SELECT 
            derivation_id,
            json_agg(json_build_object(
                'step_number', ds.step_number,
                'content', ds.content,
                'explanation', ds.explanation,
                'operation', ds.operation
            ) ORDER BY dsr.step_order) as steps
        FROM derivation_step_relations dsr
        JOIN derivation_steps ds ON dsr.step_id = ds.id
        GROUP BY derivation_id
    ) ds ON d.id = ds.derivation_id;

EOSQL

echo "数据库初始化完成!"