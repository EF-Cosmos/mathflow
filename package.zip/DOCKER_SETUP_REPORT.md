---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 3046022100b97ca5c2b1770756dba7898d6d4eccc1ce4bbc5f6d08d03bd2793c63dd45a0fa022100a3421bd7b81d0786b9ce06046ab75a04d1bb9c015c71ddcb15f2533946400497
    ReservedCode2: 304502200ab577f265cc7d096cb83ad6cf44dd789c234225089477873aa7c6f1670e3356022100c86a8a7571fa75ee1bf15a9e3b2663ca4c21b606272c5df3821ff678dcf891ce
---

# MathFlow Docker 网络和数据卷配置完成报告

## 📋 配置概述

我已经为MathFlow项目创建了完整的Docker网络和数据卷配置，包括生产环境和开发环境的详细设置。

## 🗂️ 已创建的文件和配置

### 1. 核心配置文件

#### `docker-compose.yml` - 主配置文件
- **自定义网络**: `mathflow-network` (bridge模式)
- **子网配置**: 172.20.0.0/16, 网关: 172.20.0.1
- **数据卷**: 4个持久化数据卷
  - `mathflow-db-data`: PostgreSQL数据
  - `mathflow-redis-data`: Redis数据  
  - `mathflow-uploads`: 用户上传文件
  - `mathflow-logs`: 应用日志
- **服务配置**: postgres, redis, app, nginx
- **网络访问规则**: 完整的端口映射和访问控制

#### `docker-compose.override.yml` - 开发环境覆盖配置
- **开发专用服务**: pgAdmin, Redis Commander, Portainer
- **开发端口映射**: 避免与本地服务冲突
- **开发环境数据卷**: 独立的数据存储
- **开发工具集成**: 管理界面代理配置

### 2. 数据库初始化配置

#### `docker/init-db/01-init-database.sh`
- **扩展安装**: uuid-ossp, pgcrypto, pg_trgm等
- **表结构创建**: profiles, math_templates, derivations等
- **索引优化**: 提高查询性能
- **触发器设置**: 自动更新时间戳
- **示例数据**: 演示用数据
- **视图创建**: 简化常用查询

### 3. Nginx配置

#### `docker/nginx/nginx.conf` - 生产环境
- **安全配置**: 安全头, XSS保护等
- **性能优化**: Gzip压缩, 缓存策略
- **负载均衡**: 上游服务器配置
- **限流配置**: API请求频率限制

#### `docker/nginx/conf.d/default.conf` - 站点配置
- **静态文件处理**: 长期缓存策略
- **API代理**: 反向代理配置
- **WebSocket支持**: 实时功能
- **SPA路由**: 单页应用支持

#### `docker/nginx/nginx-dev.conf` - 开发环境
- **调试友好**: 详细日志, 无缓存
- **热重载支持**: 开发时实时更新
- **管理界面代理**: pgAdmin, Redis Commander, Portainer
- **宽松限制**: 便于开发调试

### 4. 开发环境配置

#### `docker/dev/postgres.conf`
- **内存优化**: 适合开发环境的内存设置
- **详细日志**: 便于调试的日志配置
- **性能统计**: 启用查询性能监控
- **自动vacuum**: 频繁的维护设置

#### `docker/dev/redis.conf`
- **持久化配置**: RDB + AOF
- **内存管理**: 256MB限制, LRU策略
- **慢查询监控**: 性能调优
- **安全设置**: 开发环境密码配置

### 5. 管理工具

#### `Makefile` - 简化操作命令
**开发环境命令**:
- `make dev` - 启动开发环境
- `make dev-logs` - 查看开发日志
- `make dev-stop` - 停止开发环境

**生产环境命令**:
- `make prod` - 启动生产环境
- `make prod-logs` - 查看生产日志
- `make prod-stop` - 停止生产环境

**管理命令**:
- `make build` - 构建镜像
- `make restart` - 重启服务
- `make ps` - 查看服务状态
- `make clean` - 清理环境
- `make backup` - 备份数据
- `make restore` - 恢复数据
- `make health` - 健康检查

#### `init-docker.sh` - 环境初始化脚本
- **目录创建**: 自动创建必要目录
- **权限设置**: 适当的文件权限
- **配置验证**: 检查配置文件
- **端口检查**: 验证端口可用性
- **使用说明**: 详细的操作指南

#### `.env.example` - 环境变量示例
- **数据库配置**: PostgreSQL和Redis
- **应用配置**: Node.js应用设置
- **Supabase集成**: 数据库和认证
- **AI服务配置**: OpenAI API设置
- **安全配置**: JWT密钥, 加密密钥
- **监控配置**: 性能监控设置

### 6. 文档

#### `docker/README.md` - 详细使用文档
- **目录结构**: 完整的文件组织
- **网络配置**: 详细的网络设置说明
- **数据卷配置**: 持久化存储策略
- **使用方法**: 启动和管理指南
- **故障排除**: 常见问题解决方案

## 🌐 网络配置详情

### 数学流网络 (mathflow-network)
- **驱动类型**: bridge
- **子网**: 172.20.0.0/16
- **网关**: 172.20.0.1
- **IP范围**: 172.20.1.0/24
- **桥接接口**: mathflow-br0
- **特性**: 
  - 容器间通信 (ICC)
  - IP伪装 (IP Masquerade)
  - 外部访问支持
  - 可附加模式

### 端口映射
| 服务 | 内部端口 | 生产外部端口 | 开发外部端口 | 用途 |
|------|----------|--------------|--------------|------|
| postgres | 5432 | 5432 | 5433 | 数据库服务 |
| redis | 6379 | 6379 | 6380 | 缓存服务 |
| nginx | 80 | 80 | 8080 | 反向代理 |
| nginx | 443 | 443 | 8443 | HTTPS代理 |
| app | 3000 | - | 3000 | 应用服务 |
| pgAdmin | 80 | - | 5050 | 数据库管理 |
| Redis Commander | 8081 | - | 8081 | Redis管理 |
| Portainer | 9000 | - | 9000 | 容器管理 |

## 💾 数据卷配置详情

### 生产环境数据卷
| 卷名 | 主机路径 | 容器路径 | 用途 | 备份策略 |
|------|----------|----------|------|----------|
| `mathflow-db-data` | `./data/postgres` | `/var/lib/postgresql/data` | PostgreSQL数据 | 每日02:00 |
| `mathflow-redis-data` | `./data/redis` | `/data` | Redis持久化 | - |
| `mathflow-uploads` | `./data/uploads` | `/app/uploads` | 用户文件 | 每日03:00 |
| `mathflow-logs` | `./data/logs` | `/var/log/nginx` | 应用日志 | 保留30天 |

### 开发环境数据卷
| 卷名 | 主机路径 | 容器路径 | 用途 |
|------|----------|----------|------|
| `mathflow-db-data-dev` | `./data/dev/postgres` | `/var/lib/postgresql/data` | 开发数据库 |
| `mathflow-redis-data-dev` | `./data/dev/redis` | `/data` | 开发Redis |
| `mathflow-uploads-dev` | `./data/dev/uploads` | `/app/uploads` | 开发文件 |
| `mathflow-logs-dev` | `./data/dev/logs` | `/var/log/nginx` | 开发日志 |
| `mathflow-pgadmin-data` | `./data/dev/pgadmin` | `/var/lib/pgadmin` | pgAdmin数据 |
| `mathflow-portainer-data` | `./data/dev/portainer` | `/data` | Portainer数据 |

## 🔒 安全配置

### 网络安全
- 容器间网络隔离
- 外部访问控制
- 端口映射限制
- 防火墙规则

### 应用安全
- 密码加密 (scram-sha-256)
- SSL/TLS支持
- 安全头设置
- 请求频率限制
- CORS配置

### 数据安全
- 敏感数据加密
- 访问权限控制
- 定期备份
- 日志安全

## 🚀 使用方法

### 快速开始
```bash
# 1. 复制环境变量文件
cp .env.example .env

# 2. 编辑配置文件
vim .env

# 3. 初始化环境
bash init-docker.sh

# 4. 启动开发环境
./start.sh dev

# 或使用make命令
make dev
```

### 管理命令
```bash
# 查看所有可用命令
make help

# 开发环境管理
make dev          # 启动开发环境
make dev-logs     # 查看开发日志
make dev-stop     # 停止开发环境

# 生产环境管理
make prod         # 启动生产环境
make prod-logs    # 查看生产日志
make prod-stop    # 停止生产环境

# 维护操作
make backup       # 备份数据
make restore      # 恢复数据
make clean        # 清理环境
make health       # 健康检查
```

## 📊 监控和日志

### 日志位置
- **Nginx访问日志**: `/var/log/nginx/access.log`
- **Nginx错误日志**: `/var/log/nginx/error.log`
- **PostgreSQL日志**: `./data/postgres/log/`
- **Redis日志**: Docker容器日志
- **应用日志**: `./data/logs/app.log`

### 健康检查
- **数据库**: `pg_isready` 检查
- **Redis**: `redis-cli ping` 检查
- **Nginx**: `/health` 端点
- **应用**: 自定义健康检查端点

### 监控工具
- **pgAdmin**: 数据库管理界面
- **Redis Commander**: Redis管理界面
- **Portainer**: 容器管理界面
- **Docker Stats**: 资源监控

## 🎯 配置特点

### 1. 完整的开发环境
- 独立的数据存储
- 开发工具集成
- 热重载支持
- 详细调试日志

### 2. 生产就绪配置
- 安全加固
- 性能优化
- 监控集成
- 备份策略

### 3. 灵活的配置管理
- 环境变量配置
- 配置文件分离
- 覆盖机制
- 扩展性设计

### 4. 易于维护
- 清晰的文档
- 自动化脚本
- 标准化操作
- 故障排除指南

## 📝 下一步操作

1. **配置环境变量**: 编辑 `.env` 文件
2. **启动服务**: 使用 `make dev` 或 `make prod`
3. **验证配置**: 使用 `make health` 检查服务状态
4. **访问应用**: 根据启动模式访问相应URL

## 🔗 相关链接

- **开发环境**: http://localhost:8080
- **pgAdmin**: http://localhost:8080/pgadmin
- **Redis Commander**: http://localhost:8080/redis
- **Portainer**: http://localhost:8080/portainer

配置已完整创建，可以立即开始使用！🎉